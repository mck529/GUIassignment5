You can reach the webpage for my Assignment 4 at 

http://weblab.cs.uml.edu/~mkusmire/mk_home.html